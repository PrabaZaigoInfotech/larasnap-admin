<!DOCTYPE html>
<html lang="en">
   <?php echo $__env->make('larasnap::layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body id="page-top" class="<?php echo e($class ?? ''); ?>">
      <!-- Start Page Wrapper -->
      <div id="wrapper">
         <!-- Start Sidebar -->
         <?php echo $__env->make('larasnap::layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- End Sidebar -->
         <!-- Start Content Wrapper -->
         <div id="content-wrapper" class="d-flex flex-column">
            <!-- Start Main Content -->
            <div id="content">
               <!-- Start Topbar -->
               <?php echo $__env->make('larasnap::layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>              
               <!-- End Topbar -->
			   <?php if(config('larasnap.breadcrumb')): ?>
			   <!-- Start Breadcrumb -->
			   <?php echo $__env->make('larasnap::layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			   <!-- End Breadcrumb -->
			   <?php endif; ?>
               <!-- Start Page Content -->
               <div class="container-fluid">
			   <!-- start success message -->
			    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<?php echo e(session('success')); ?>          
                    </div>
				<?php endif; ?>	
				<!-- end success message -->
			    <!-- start error message -->
			    <?php if(session('error')): ?>				
				    <div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<?php echo e(session('error')); ?>

					</div>
				<?php endif; ?>					
				 <!-- end error message -->
                  <?php echo $__env->yieldContent('content'); ?>
               </div>
               <!-- End Page Content -->
            </div>
            <!-- End Main Content -->
            <!-- Footer Copyright -->
            <?php echo $__env->make('larasnap::layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer Copyright -->
         </div>
         <!-- End  Content Wrapper -->
      </div>
      <!-- End Page Wrapper -->
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
      </a>
      <?php echo $__env->make('larasnap::layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('script'); ?>
   </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/layouts/app.blade.php ENDPATH**/ ?>