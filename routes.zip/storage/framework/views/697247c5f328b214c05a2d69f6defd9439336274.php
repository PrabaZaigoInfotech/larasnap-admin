<?php $__env->startSection('title','Module Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Modules</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-md-8">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
				<form  method="POST" action="<?php echo e(route('modules.index')); ?>" id="list-form" class="form-inline my-2 my-lg-0" autocomplete="off">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
			   <div class="col-md-3 pad-0">
                    <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.create')): ?>
                        <a href="#" title="Add New Module" class="btn btn-primary btn-sm module-add"><i aria-hidden="true" class="fa fa-plus"></i> Add New Module
                        </a>
                   <?php endif; ?>
			   </div>
				<!-- list filters -->
				<div class="col-md-9 filters">
					<?php echo $__env->make('larasnap::list-filters.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>	
				<!-- list filters -->
               <br> <br> 
               <div class="table-responsive">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>ID</th>
                           <th>Label</th>
                           <th>Actions</th>
                        </tr>
                     </thead>
                     <tbody>
					<?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
                        <tr>
                           <td><?php echo e($module->id); ?></td>
                           <td><?php echo e($module->label); ?></td>
                           <td>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.edit')): ?>
							  <a href="#" title="Edit Module" data-id="<?php echo e($module->id); ?>" data-label="<?php echo e($module->label); ?>" class="module-edit"><button class="btn btn-primary btn-sm" type="button"><i aria-hidden="true" class="fa fa-pencil-square-o"></i></button></a>
                               <?php endif; ?>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.destroy')): ?>
                               <a href="#" onclick="return individualDelete(<?php echo e($module->id); ?>)" title="Delete Module"><button class="btn btn-danger btn-sm" type="button"><i aria-hidden="true" class="fa fa-trash"></i></button></a>
                               <?php endif; ?>
                           </td>
                        </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td class="text-center" colspan="12">No Module found!</td>
						</tr>
						<?php endif; ?>

                     </tbody>
                  </table>
                  <div class="pagination">
					<?php echo e($modules->links()); ?>

				  </div>
               </div>
			   </form>
            </div>
            <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.destroy')): ?>
                <p>Deleting module doesn't delete all the screens mapped to them, instead will delete only the module & all screens mapped to the module will move to the no-module list.</p>
            <?php endif; ?>
         </div>
      </div>
   </div>
   <div class="col-md-4">
       <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.create')): ?>
       <div class="card shadow mb-4 module-add-form">
         <div class="card-body">
            <div class="card-body">
                  <h1 class="h3 text-gray-800 mb-10 module-form-title">Add Module</h1>
                  <form method="POST" action="<?php echo e(route('modules.store')); ?>"  class="form-horizontal" autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label for="label" class="control-label">Label<small class="text-danger required">*</small></label> 
                           <input name="label" type="text" id="module-label" class="form-control" value="">
                           <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-4">
                        <div class="form-group">
                           <input type="submit" value="Save" id="module-submit" class="btn btn-primary">
                        </div>
                     </div>
                  </div>
                  </form>
            </div>
         </div>
        </div> 
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.edit')): ?>
        <div class="card shadow mb-4 module-edit-form">
         <div class="card-body">
            <div class="card-body">
                  <h1 class="h3 text-gray-800 mb-10 module-form-title">Edit Module</h1>
                  <form method="POST" action="<?php echo e(route('modules.index')); ?>"  class="form-horizontal" autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label for="label" class="control-label">Label<small class="text-danger required">*</small></label> 
                           <input name="label" type="text" id="module-edit-label" class="form-control" value="">
                           <input name="module_id" type="hidden" id="module-edit-id" value="">
                           <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-4">
                        <div class="form-group">
                           <input type="submit" value="Update" id="module-update" class="btn btn-primary">
                        </div>
                     </div>
                  </div>
                  </form>
            </div>
         </div>
       </div>
       <?php endif; ?>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'module-index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/modules/index.blade.php ENDPATH**/ ?>