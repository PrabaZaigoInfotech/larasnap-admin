<?php if(config('larasnap.module_list.screen.search')): ?>				 
   <input type="text" name="search" placeholder="Search Screen..." class="form-control ml-10" value="<?php echo e($filters['search']); ?>" data-toggle="tooltip" data-placement="top" title="Search by screen label">
<?php endif; ?>				  
<?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/list-filters/screen.blade.php ENDPATH**/ ?>