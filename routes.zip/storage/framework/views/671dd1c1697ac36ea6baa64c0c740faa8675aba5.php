<?php $__env->startSection('title','Screen Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Assign Roles to Screen(<?php echo e($screen->label); ?>)</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <a href="<?php echo e(route('screens.index')); ?>" title="Back to Screens List" class="btn btn-warning btn-sm"><i aria-hidden="true" class="fa fa-arrow-left"></i> Back to Screens List
               </a> 
               <br> <br> 
               <form action="<?php echo e(route('screens.assignrole_store', $screen->id)); ?>" method="POST">
			      <?php echo csrf_field(); ?>
                  <?php if($roles->isNotEmpty()): ?>
                  <div class="checkbox">
                     <label><input type="checkbox" id="bulk-checkall" > <strong>Check All Roles</strong></label>
                  </div>
                  <?php endif; ?>
                  <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="checkbox">
                     <label><input type="checkbox" <?php if(in_array($id, $screen_roles)): ?> checked <?php endif; ?> class="assign-check bulk-check" value="<?php echo e($id); ?>" name="roles[]" data-msg="role per screen"> <?php echo e($name); ?></label>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p>No Roles</p>
                  <?php endif; ?>
                  <?php if($roles->isNotEmpty()): ?>    
                        <input type="submit" value="Update" class="btn btn-primary"> 
                   <?php endif; ?>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
   <script>
       var maximum_roles_selection = <?php echo e(config('larasnap.module_list.screen.maximum_role_selection')); ?>;
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'screenmanagement-assignrole'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/screens/assignrole.blade.php ENDPATH**/ ?>