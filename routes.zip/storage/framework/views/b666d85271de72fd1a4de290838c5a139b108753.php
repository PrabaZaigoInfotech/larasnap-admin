<?php $__env->startSection('title','User Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Assign Roles to User(<?php echo e($user->full_name); ?>)</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <a href="<?php echo e(route('users.index')); ?>" title="Back to Users List" class="btn btn-warning btn-sm"><i aria-hidden="true" class="fa fa-arrow-left"></i> Back to Users List
               </a> 
               <br> <br> 
               <form action="<?php echo e(route('users.assignrole_store', $user->id)); ?>" method="POST">
			      <?php echo csrf_field(); ?>
                  <?php if($roles->isNotEmpty()): ?>
                  <div class="checkbox">
                     <label><input type="checkbox" id="bulk-checkall" > <strong>Check All Roles</strong></label>
                  </div>
                  <?php endif; ?>
                  <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="checkbox">
                     <label><input type="checkbox" <?php if(in_array($id, $user_roles)): ?> checked <?php endif; ?> class="assign-check bulk-check" value="<?php echo e($id); ?>" name="roles[]" data-msg="role per user"> <?php echo e($name); ?></label>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p>No Roles</p>
                  <?php endif; ?>
				  <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div>	
						<span class="text-danger"><?php echo e($message); ?></span>
					</div> 
				  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 	  
                  <?php if($roles->isNotEmpty()): ?>
                    <input type="submit" value="Update" class="btn btn-primary"> 
                  <?php endif; ?>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
	var maximum_roles_selection = <?php echo e(config('larasnap.module_list.user.maximum_role_selection')); ?>;
</script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'user-assignrole'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/users/assignrole.blade.php ENDPATH**/ ?>