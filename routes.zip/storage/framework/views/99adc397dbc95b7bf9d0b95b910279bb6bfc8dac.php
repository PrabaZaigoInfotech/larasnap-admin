<?php if(config('larasnap.module_list.role.search')): ?>				 
   <input type="text" name="search" placeholder="Search Role..." class="form-control ml-10" value="<?php echo e($filters['search']); ?>" data-toggle="tooltip" data-placement="top" title="Search by role label">
<?php endif; ?>				  
<?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/list-filters/role.blade.php ENDPATH**/ ?>