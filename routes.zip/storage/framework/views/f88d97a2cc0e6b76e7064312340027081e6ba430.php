<ol class="dd-list">
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li class="dd-item" data-id="<?php echo e($item->id); ?>">
      <div class="pull-right item_actions">
         <form class="menu-item-destroy" action="<?php echo e(route('menus.item.destory', $item->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-danger pull-right delete" title="Delete Menu Item" onclick="return confirm('Are you sure, you want to delete the menu item?')"><i class="fa fa-trash"></i></button>
         </form>
         <div class="btn btn-sm btn-primary pull-right edit edit_item"
            data-id="<?php echo e($item->id); ?>"
            data-title="<?php echo e($item->title); ?>"
            data-icon="<?php echo e($item->icon); ?>"
            data-target="<?php echo e($item->target); ?>"
            data-url="<?php echo e($item->url); ?>"
            data-route="<?php echo e($item->route); ?>"
            data-parameter="<?php echo e(json_encode($item->route_parameter)); ?>"
            title="Edit Menu Item" >
            <i class="fa fa-pencil-square-o"></i>
         </div>
      </div>
      <div class="dd-handle">
         <span><?php echo e($item->title); ?></span> <small class="url"></small>
      </div>
      <?php if(!$item->children->isEmpty()): ?>
      <?php echo $__env->make('larasnap::menus.template.admin', ['items' => $item->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
   </li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
<?php if($items->isEmpty()): ?>
   <p class="text-center">No menu-item assigned!</p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/menus/template/admin.blade.php ENDPATH**/ ?>