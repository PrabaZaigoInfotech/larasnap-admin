<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="container">
   <div class="row admin">
        <div class="col-lg-3 col-sm-6">
            <div class="card-box bg-green">
                <div class="inner">
                    <h3> <?php echo e($usersActiveCount); ?> </h3>
                    <h5> Active Users </h5>
                </div>
                <div class="icon">
                    <i class="fa fa-users" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card-box bg-red">
                <div class="inner">
                    <h3> <?php echo e($usersInactiveCount); ?> </h3>
                    <h5> Inactive Users </h5>
                </div>
                <div class="icon">
                    <i class="fa fa-users" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card-box bg-blue">
                <div class="inner">
                    <h3> <?php echo e($rolesCount); ?> </h3>
                    <h5> Roles </h5>
                </div>
                <div class="icon">
                    <i class="fa fa-lock" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6">
            <div class="card-box bg-orange">
                <div class="inner">
                    <h3> <?php echo e($screensCount); ?> </h3>
                    <h5> Screens </h5>
                </div>
                <div class="icon">
                    <i class="fa fa-desktop"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('larasnap::layouts.app', ['class' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/dashboard.blade.php ENDPATH**/ ?>