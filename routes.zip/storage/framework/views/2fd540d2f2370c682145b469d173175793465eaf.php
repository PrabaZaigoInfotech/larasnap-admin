<?php if(config('larasnap.module_list.category_parent.search')): ?>				 
   <input type="text" name="search" placeholder="Search Parent Category..." class="form-control ml-10" value="<?php echo e($filters['search']); ?>" data-toggle="tooltip" data-placement="top" title="Search by parent category label">
<?php endif; ?>				  
<?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/list-filters/category-parent.blade.php ENDPATH**/ ?>