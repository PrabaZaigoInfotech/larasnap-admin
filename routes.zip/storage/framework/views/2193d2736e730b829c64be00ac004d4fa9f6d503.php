<?php if(!isset($innerLoop)): ?>
   <ul class="menus main" id="accordionSidebar">
       <?php
           $i = 1; //main menu - initialize loop value
           $j = 0; //sub-menu - initialize loop value
       ?>
<?php else: ?>
    <ul class="navbar-nav sub-menu">
<?php endif; ?>

    <!-- iterate every menu-item main/sub-menu -->
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $originalItem   = $item;
            //iniatilize the variables for no-conflict
            $linkClass      = null;
            $linkAttributes = null;
            if(isset($item->icon) && !empty($item->icon)){
                $icon       = $item->icon;
            }else{
                $icon       = config('larasnap.menu.default_icon');
            }
             if(url($item->link()) == url()->current()){
                $listItemClass = 'active';
            }else{
                $listItemClass = '';
            }

            // With Children Attributes
            if(!$originalItem->children->isEmpty()) {
                $iteration      =  $i.$j;
                $target         = 'collapse'.$iteration;
                $target_parent  =  $iteration == 10 ? 'accordionSidebar' : $target; //represents 'li' element parent(ul) - immediate parent, wrapper element(div)
                $linkClass      = 'collapsed';
                $linkAttributes = 'data-toggle="collapse" data-target="#'.$target.'" aria-expanded="true" aria-controls="'.$target.'"';
            }
        ?>

    <!-- menu-item-->
    <li class="nav-item <?php echo e($listItemClass); ?>">
        <a class="nav-link <?php echo e($liClass ?? ''); ?>" href="<?php echo e(url($item->link())); ?>" target="<?php echo e($item->target); ?>" <?php echo $linkAttributes ?? ''; ?>>
            <i class="fas fa-fw <?php echo e($icon); ?>"></i>
            <span><?php echo e($item->title); ?></span></a>

        <!-- if menu item has sub-menu-item call blade recursive -->
        <?php if(!$originalItem->children->isEmpty()): ?>
            <?php $j++; ?>
            <div id="<?php echo e($target); ?>" class="collapse" data-parent="#<?php echo e($target_parent); ?>">
                <div class="bg-white py-2 collapse-inner rounded">
            <!-- recursive -->
            <?php echo $__env->make('larasnap::menus.template.default', ['items' => $originalItem->children, 'innerLoop' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- recursive -->
                </div>
            </div>
        <?php endif; ?>
    <!-- if menu item has sub-menu-item call blade recursive -->

    </li>
    <!-- menu-item-->
    <?php $i++; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- iterate every menu-item main/sub-menu -->

</ul><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/menus/template/default.blade.php ENDPATH**/ ?>