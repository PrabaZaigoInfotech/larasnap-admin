<?php $__env->startSection('title','Role Management'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Heading  Start-->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Assign Screen to Role(<?php echo e($role->label); ?>)</h1>
    </div>
    <!-- Page Heading End-->
    <!-- Page Content Start-->
    <div class="row">
        <div class="col-xl-12">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="card-body">
                        <a href="<?php echo e(route('roles.index')); ?>" title="Back to Roles List" class="btn btn-warning btn-sm"><i aria-hidden="true" class="fa fa-arrow-left"></i> Back to Roles List
                        </a>
                        <br> <br>
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="checkbox">
                            <?php if($modules->isNotEmpty()): ?>
                                <label><input type="checkbox" id="bulk-checkall" > <strong>Check All Screens</strong></label>
                            <?php endif; ?>
                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6">
                                <!-- CONTENT -->
                                <div id="accordion" class="accordion">
                                    <div class="card mb-0">
                                        <div class="card-header collapsed" data-toggle="collapse" href="#collapse<?php echo e($id); ?>">
                                            <a class="card-title"> <?php echo e($module->label); ?> (<?php echo e($module->screens_count); ?>)</a>
                                        </div>
                                        <div id="collapse<?php echo e($id); ?>" class="card-body collapse" data-parent="#accordion">
                                                <?php $__empty_2 = true; $__currentLoopData = $module->screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <div class="checkbox">
                                                        <label><input type="checkbox" <?php if(in_array($screen->id, $role_screens)): ?> checked <?php endif; ?> class="assign-check bulk-check" value="<?php echo e($screen->id); ?>" name="screens[]" data-msg="screen per role"> <?php echo e($screen->label); ?></label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <?php endif; ?>                                               
                                        </div>
                                    </div>
                                </div>
                                <!-- CONTENT -->
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>No Module</p>
                                <?php endif; ?>
                            </div> 
                            <?php if($modules->isNotEmpty()): ?>
                                <input type="submit" value="Update" class="btn btn-primary mt-10">
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Content End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var maximum_roles_selection = <?php echo e(config('larasnap.module_list.role.maximum_screen_selection')); ?>;
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'rolemanagement-assignscreen'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/roles/assignscreen.blade.php ENDPATH**/ ?>