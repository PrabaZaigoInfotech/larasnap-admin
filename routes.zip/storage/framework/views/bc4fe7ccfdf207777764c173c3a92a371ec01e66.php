<?php $__env->startSection('title','Role Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Assign Permissions to Role(<?php echo e($role->label); ?>)</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <a href="<?php echo e(route('roles.index')); ?>" title="Back to Roles List" class="btn btn-warning btn-sm"><i aria-hidden="true" class="fa fa-arrow-left"></i> Back to Roles List
               </a> 
               <br> <br> 
               <form action="<?php echo e(route('roles.assignpermission_store', $role->id)); ?>" method="POST">
			      <?php echo csrf_field(); ?>
                  <div class="checkbox">
                    <?php if($permissions->isNotEmpty()): ?>
                        <label><input type="checkbox" id="bulk-checkall" > <strong>Check All Permissions</strong></label>
                    <?php endif; ?>
                  </div>
                  <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="checkbox">
                     <label><input type="checkbox" <?php if(in_array($id, $role_permissions)): ?> checked <?php endif; ?> class="assign-check bulk-check" value="<?php echo e($id); ?>" name="permission[]" data-msg="permission per role"> <?php echo e($name); ?></label>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p>No Permission</p>
                  <?php endif; ?>
                  <?php if($permissions->isNotEmpty()): ?>
                        <input type="submit" value="Update" class="btn btn-primary"> 
                  <?php endif; ?>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
   <script>
       var maximum_roles_selection = <?php echo e(config('larasnap.module_list.role.maximum_permission_selection')); ?>;
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'rolemanagement-assignpermission'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/roles/assignpermission.blade.php ENDPATH**/ ?>