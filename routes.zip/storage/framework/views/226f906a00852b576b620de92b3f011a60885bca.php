<footer class="sticky-footer">
   <div class="container my-auto">
      <div class="copyright text-center my-auto">
         <span>Copyright &copy; <?php echo e(setting('site_name')); ?> <?php echo e(date('Y')); ?></span>
      </div>
   </div>
</footer><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/layouts/footer.blade.php ENDPATH**/ ?>