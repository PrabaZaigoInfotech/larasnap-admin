<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('vendor/larasnap/js/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/larasnap/js/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('vendor/larasnap/js/jquery-easing/jquery.easing.min.js')); ?>"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('vendor/larasnap/js/larasnap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/larasnap/js/larasnap-custom.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/larasnap/js/jquery.nestable.js')); ?>"></script>
<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/layouts/foot.blade.php ENDPATH**/ ?>