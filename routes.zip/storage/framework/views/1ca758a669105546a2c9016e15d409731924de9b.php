
<?php $__env->startSection('title','Menu Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Lists</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <form  method="POST" action="" id="list-form" class="form-inline my-2 my-lg-0" autocomplete="off">
                  <?php echo method_field('POST'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="col-md-2 pad-0">
                     <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'menus.create')): ?>
                     <a href="<?php echo e(route('employees.create')); ?>" title="Add New Menu" class="btn btn-primary btn-sm"><i aria-hidden="true" class="fa fa-plus"></i> Add New Employee
                     </a>
                     <?php endif; ?>
                  </div>
                  <!-- list filters -->
                  
                  <!-- list filters -->
                  <br> <br> 
                  <div class="table-responsive">
                     <table class="table">
                        <thead>
                           <tr>
                              <th>ID</th>
                              <th>FirstName</th>
                              <th>LastName</th>
                              <th>Gender</th>
                              <th>CityName</th>
                              <th>Phone</th>
                              <th>Email</th>
                              <th>Actions</th>
                           </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                           <tr>
                              <td><?php echo e($employees->id); ?></td>
                              <td><?php echo e($employees->first_name); ?></td>
                              <td><?php echo e($employees->last_name); ?></td>
                              <td><?php echo e($employees->gender); ?></td>
                              <td><?php echo e($employees->city); ?></td>
                              <td><?php echo e($employees->phone_number); ?></td>
                              <td><?php echo e($employees->email); ?></td>
                              <td>
								 <?php if (\Illuminate\Support\Facades\Blade::check('showData', 'menu', $employees->name)): ?>
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'menus.edit')): ?>
                                 <a href="<?php echo e(route('employees.edit', $employees->id)); ?>" title="Edit Menu"><button class="btn btn-primary btn-sm" type="button"><i aria-hidden="true" class="fa fa-pencil-square-o"></i></button></a>
                                 <?php endif; ?>
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'menus.destroy')): ?>
                                 <a href="#" onclick="return individualDelete(<?php echo e($employees->id); ?>)" title="Delete Menu"><button class="btn btn-danger btn-sm" type="button"><i aria-hidden="true" class="fa fa-trash"></i></button></a>
                                 <?php endif; ?>
								 <?php endif; ?>
                              </td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr>
                              <td class="text-center" colspan="12">No Menu found!</td>
                           </tr>
                        <?php endif; ?>
                     </tbody>
                     </table>
                     <div class="pagination">
                        <?php echo e($employee->links()); ?>

                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'menu-index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/employee/index.blade.php ENDPATH**/ ?>