 <?php if(config('larasnap.module_list.user.sort_by')): ?>
   <select name="sort_by"  id="sort-by" class="form-control" onchange="filter(this.value)">
      <?php $__currentLoopData = config('larasnap.module_list.user.sort_by'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option <?php if($filters['sort_by'] == $option['value']): ?> selected <?php endif; ?>  value="<?php echo e($option['value']); ?>"><?php echo e($option['label']); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
   <?php endif; ?>				 
   <?php if(config('larasnap.module_list.user.filter.role')): ?>
   <select name="user_role" id="role" class="form-control ml-10" onchange="filterByID(this)">
      <option value="all" >All Roles</option>
      <option value="no_role" <?php if($filters['user_role'] == 'no_role' ): ?> selected <?php endif; ?> >No Role</option>
	  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option <?php if($filters['user_role'] == $id ): ?> selected <?php endif; ?> value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
   <?php endif; ?>
   <?php if(config('larasnap.module_list.user.status')): ?>
   <select name="user_status" id="users" class="form-control ml-10" onchange="filterByID(this)">
      <?php $__currentLoopData = config('larasnap.module_list.user.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option <?php if($filters['user_status'] == $option['value']): ?> selected <?php endif; ?>  value="<?php echo e($option['value']); ?>"><?php echo e($option['label']); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
   <?php endif; ?>
   <?php if(config('larasnap.module_list.user.bulk_actions')): ?>
   <select name="actions" id="actions" class="form-control ml-10" onchange="filterBulk(this.value)">
      <option selected disabled value="0">Bulk Actions</option>
      <?php $__currentLoopData = config('larasnap.module_list.user.bulk_actions'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($option['value']); ?>"><?php echo e($option['label']); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
   <?php endif; ?>	
   <?php if(config('larasnap.module_list.user.search')): ?>				 
   <input type="text" name="search" placeholder="Search User..." class="form-control ml-10" value="<?php echo e($filters['search']); ?>" data-toggle="tooltip" data-placement="top" title="Search by user first name or last name or both">
   <?php endif; ?>				  
<?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/list-filters/user.blade.php ENDPATH**/ ?>