
<?php $__env->startSection('title','Menu Management'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Page Heading  Start-->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800">Add Menu</h1>
	</div>
	<!-- Page Heading End-->
	<!-- Page Content Start-->
	<div class="row">
		<div class="col-xl-12">
			<div class="card shadow mb-4">
				<div class="card-body">
					<div class="card-body">
						<a href="<?php echo e(route('employees.index')); ?>" title="Back to Menu List" class="btn btn-warning btn-sm"><i aria-hidden="true" class="fa fa-arrow-left"></i> Back to Menu List
						</a>
						<br> <br>
                        <form class="table row col-xl-9" style="margin-left:200px" method="post" action="<?php echo e(route('employees.update')); ?>" enctype="multipart/form-data" >
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('put'); ?>
                         <div class="row">
                         <div class="col-xl-12  text-center mb-4">
                         <h4>Register<h4>
                        </div>
                        <input type="hidden" name="id" value="<?php echo e($employee['id']); ?>" />
                        <div class="col-xl-6">
                            <lable for="first_name">FirstName</lable></div>
                            <div class="col-xl-6 mb-4 text-danger">
                                <input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name', $employee->first_name)); ?>"/>
                                <?php if($errors->has('first_name')): ?>
                                 <?php echo e($errors->first('first_name')); ?>

                                 <?php endif; ?>
                             </div>
            <div class="col-xl-6 ">
            <lable for="last_name">LastName</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name', $employee->last_name)); ?>"/>
            <?php if($errors->has('last_name')): ?>
                <?php echo e($errors->first('last_name')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="gender">Gender</lable></div>
            <div class="col-xl-6 mb-4">
            <input type="radio" name="gender" value="male" <?php echo e($employee['gender'] == 'male' ? 'checked' : ''); ?> />Male
            <input type="radio" name="gender" value="female" <?php echo e($employee['gender'] == 'female' ? 'checked': ''); ?> />Female
            <?php if($errors->has('gender')): ?>
                <?php echo e($errors->first('gender')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="city">CityName</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="text" name="city" class="form-control"  value="<?php echo e(old('city', $employee->city)); ?>"/>
            <?php if($errors->has('city')): ?>
                <?php echo e($errors->first('city')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="phone_number">PhoneNumber</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="number" name="phone_number" class="form-control" value="<?php echo e(old('phone_number', $employee->phone_number)); ?>"/>
            <?php if($errors->has('phone_number')): ?>
                <?php echo e($errors->first('phone_number')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="date_of_birth">Date-Of-Birth</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="date" name="date_of_birth" class="form-control" value="<?php echo e(old('date_of_birth', $employee->date_of_birth)); ?>"/>
            <?php if($errors->has('date_of_birth')): ?>
                <?php echo e($errors->first('date_of_birth')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="email">Email</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="text" name="email" class="form-control" value="<?php echo e(old('email', $employee->email)); ?>"/>
            <?php if($errors->has('email')): ?>
                <?php echo e($errors->first('email')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="password">Password</lable></div>
            <div class="col-xl-6 mb-4 text-danger">
            <input type="password" name='password' class="form-control" value="<?php echo e(old('password')); ?>"/>
            <?php if($errors->has('password')): ?>
                <?php echo e($errors->first('password')); ?>

            <?php endif; ?>
            </div>
            <div class="col-xl-6">
            <lable for="confirm_password">Confirm Password</lable></div>
            <div class="col-xl-6 mb-4">
            <input type="password" name="confirm_password" class="form-control" value="<?php echo e(old('confirm_passwors')); ?>"/>
            </div>
            <div class="col-xl-6">
            <lable>Submit</lable></div>
            <div class="col-xl-6 mb-4">
            <input type="submit" value="update" class="btn btn-primary"/></div>
            </div>
        </form>
        </div>
        </div>
        </div>
        </div>
        </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('larasnap::layouts.app', ['class' => 'menu-create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/employee/edit.blade.php ENDPATH**/ ?>