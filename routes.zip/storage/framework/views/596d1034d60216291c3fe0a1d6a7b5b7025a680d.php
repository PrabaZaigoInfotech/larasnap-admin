<?php $__env->startSection('title','Site Settings'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Settings</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <form method="POST" action="<?php echo e(route('settings.store')); ?>"  class="form-horizontal" enctype="multipart/form-data" autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="name" class="control-label">Site Name<small class="text-danger required">*</small></label> 
                           <input name="site_name" type="text" id="site-name" class="form-control" value="<?php echo e(old('name', $setting_db_values['site_name'])); ?>">
                           <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="">
                           <label for="logo" class="control-label">Site Logo</label> 
                           <input name="site_logo" type="file" id="site-logo" class="form-control" >
                           <small>Allowed File Formats: jpg, jpeg, png</small>
                           <?php $__errorArgs = ['site_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="admin-email" class="control-label">Admin Email<small class="text-danger required">*</small></label> 
                           <input name="admin_email" type="email" id="admin-email" class="form-control" value="<?php echo e(old('admin_email', $setting_db_values['admin_email'])); ?>">
                           <?php $__errorArgs = ['admin_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="date-format" class="control-label">Date Format<small class="text-danger required">*</small></label> 
                           <select class="form-control ts"  name="date_format" id="date-format" >
                              <option value=""  selected="selected" disabled="disabled">Select Date Format</option>
                              <?php $__currentLoopData = config('larasnap.settings.date_format'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($value); ?>" <?php if(old('date_format', $setting_db_values['date_format']) == $value ): ?> selected <?php endif; ?>><?php echo e(date($value)); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <?php $__errorArgs = ['date_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="date-time-format" class="control-label">Date Time Format<small class="text-danger required">*</small></label>
                           <select class="form-control ts"  name="date_time_format" id="date-time-format" >
                              <option value=""  selected="selected" disabled="disabled">Select Date Time Format</option>
                              <?php $__currentLoopData = config('larasnap.settings.date_time_format'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($value); ?>" <?php if(old('date_time_format',$setting_db_values['date_time_format']) == $value ): ?> selected <?php endif; ?>><?php echo e(date($value)); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <?php $__errorArgs = ['date_time_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="time-format" class="control-label">Time Format<small class="text-danger required">*</small></label>
                           <select class="form-control ts"  name="time_format" id="time-format" >
                              <option value=""  selected="selected" disabled="disabled">Select Time Format</option>
                              <?php $__currentLoopData = config('larasnap.settings.time_format'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($value); ?>" <?php if(old('time_format',$setting_db_values['time_format']) == $value ): ?> selected <?php endif; ?>><?php echo e(date($value)); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <?php $__errorArgs = ['time_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="entries-per-page" class="control-label">Entries Per Page<small class="text-danger required">*</small></label> 
                           <input name="entries_per_page" type="number" id="entries-per-page" class="form-control" min="1" max="25" value="<?php echo e(old('entries_per_page', $setting_db_values['entries_per_page'])); ?>">
                           <?php $__errorArgs = ['entries_per_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label for="default-user-role" class="control-label">Default User Role<small class="text-danger required">*</small></label> 
                           <select class="form-control ts"  name="default_user_role" id="default-user-role" >
                              <option value="0"  selected="selected">No Role</option>
                              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>" <?php if(old('default_user_role',$setting_db_values['default_user_role'] ?? '') == $role->id ): ?> selected <?php endif; ?> ><?php echo e($role->label); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                            <?php $__errorArgs = ['default_user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 							
                        </div>
                     </div>
                     <div class="col-md-12">
                        <div class="form-group">
                           <input type="submit" value="Update" class="btn btn-primary">
                        </div>
                     </div>
                  </div>
               </form>
               <p>Time Zone: <?php echo e(config('app.timezone')); ?></p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'settings-create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/settings/create.blade.php ENDPATH**/ ?>