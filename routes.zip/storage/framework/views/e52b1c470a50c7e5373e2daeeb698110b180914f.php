<?php $__env->startSection('title','User Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Users</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
               <form  method="POST" action="<?php echo e(route('users.index')); ?>" id="list-form" class="form-inline my-2 my-lg-0" autocomplete="off">
                  <?php echo method_field('POST'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="col-md-2 pad-0">
                     <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'users.create')): ?>
                     <a href="<?php echo e(route('users.create')); ?>" title="Add New User" class="btn btn-primary btn-sm"><i aria-hidden="true" class="fa fa-plus"></i> Add New User
                     </a>
                     <?php endif; ?>
                  </div>
                  <!-- list filters -->
                  <div class="col-md-10 filters">
                     <?php echo $__env->make('larasnap::list-filters.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <!-- list filters -->
                  <br> <br> 
                  <div class="table-responsive">
                     <table class="table">
                        <thead>
                           <tr>
                              <th><input type="checkbox" id="bulk-checkall"></th>
                              <th>ID</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Role</th>
                              <th>Status</th>
                              <th>Actions</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              $superAdminRole = config('larasnap.superadmin_role');
                           ?>
                           <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                           <tr>
                              <?php if(isset($superAdminRole) && !empty($superAdminRole) && $user->roles->contains('name', $superAdminRole) && !userHasRole($superAdminRole)): ?> 
                                  <td><input type="checkbox" class="checkbox" name="records[]" value="" disabled></td>
                              <?php else: ?>
                                <td><input type="checkbox" class="checkbox bulk-check" name="records[]" value="<?php echo e($user->id); ?>" data-id="<?php echo e($user->id); ?>"></td>
                              <?php endif; ?>
                              <td><?php echo e($user->id); ?></td>
                              <td><?php echo e($user->full_name); ?></td>
                              <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                              <td>
                                 <?php $__empty_2 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                 <span class="badge badge-success badge-role"><?php echo e($role->label); ?></span>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                 <span class="badge badge-danger">No Role</span>									
                                 <?php endif; ?>
                              </td>
                              <td><?php echo e($user->status_info); ?></td>
                              <td>
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'users.show')): ?>
                                 <a href="<?php echo e(route('users.show', $user->id)); ?>" title="View User"><button class="btn btn-info btn-sm" type="button"><i aria-hidden="true" class="fa fa-eye"></i></button></a>
                                 <?php endif; ?>
                                 <!-- If 'Super Admin Role' is added on the config & if the user has 'Super Admin Role', show the edit/assign role/delete options only if the logged in user has 'Super Admin Role' -->
                                 <?php if(isset($superAdminRole) && !empty($superAdminRole)): ?>
                                     <?php if($user->roles->contains('name', $superAdminRole) && !userHasRole($superAdminRole)): ?> 
                                         <?php continue; ?>;
                                     <?php endif; ?>    
                                 <?php endif; ?>    
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'users.edit')): ?>
                                     <a href="<?php echo e(route('users.edit', $user->id)); ?>" title="Edit User"><button class="btn btn-primary btn-sm" type="button"><i aria-hidden="true" class="fa fa-pencil-square-o"></i></button></a>
                                 <?php endif; ?>
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'users.assignrole_create')): ?>
                                     <a href="<?php echo e(route('users.assignrole_create', $user->id)); ?>" title="Assign Role"><button class="btn btn-success btn-sm" type="button"><i aria-hidden="true" class="fa fa-key"></i></button></a>
                                 <?php endif; ?>
                                 <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'users.destroy')): ?>
                                     <a href="#" onclick="return individualDelete(<?php echo e($user->id); ?>)" title="Delete User"><button class="btn btn-danger btn-sm" type="button"><i aria-hidden="true" class="fa fa-trash"></i></button></a>
                                 <?php endif; ?>
                              </td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr>
                              <td class="text-center" colspan="12">No User found!</td>
                           </tr>
                           <?php endif; ?>
                        </tbody>
                     </table>
                     <div class="pagination">
                        <?php echo e($users->links()); ?>

                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'user-index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/users/index.blade.php ENDPATH**/ ?>