<?php $__env->startSection('title','Screen Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Screens</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
				<form  method="POST" action="<?php echo e(route('screens.index')); ?>" id="list-form" class="form-inline my-2 my-lg-0" autocomplete="off">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
			   <div class="col-md-2 pad-0">
                   <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'screens.create')): ?>
               <a href="<?php echo e(route('screens.create')); ?>" title="Add New Screen" class="btn btn-primary btn-sm"><i aria-hidden="true" class="fa fa-plus"></i> Add New Screen
               </a>
                   <?php endif; ?>
			   </div>
               <div class="col-md-2 pad-0">
                   <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'modules.index')): ?>
               <a href="<?php echo e(route('modules.index')); ?>" title="Manage Modules" class="btn btn-primary btn-sm">Manage Modules
               </a>
                   <?php endif; ?>
			   </div>
				<!-- list filters -->
				<div class="col-md-8 filters">
					<?php echo $__env->make('larasnap::list-filters.screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>	
				<!-- list filters -->
               <br> <br> 
               <div class="table-responsive">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>ID</th>
                           <th>Name(Route Name)</th>
                           <th>Label</th>
                           <th>Module</th>
                           <th>Actions</th>
                        </tr>
                     </thead>
                     <tbody>
					<?php $__empty_1 = true; $__currentLoopData = $screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
                        <tr>
                           <td><?php echo e($screen->id); ?></td>
                           <td><?php echo e($screen->name); ?></td>
                           <td><?php echo e($screen->label); ?></td>
                           <td><?php echo e($screen->module ? $screen->module->label : ''); ?></td>
                           <td>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'screens.edit')): ?>
							  <a href="<?php echo e(route('screens.edit', $screen->id)); ?>" title="Edit Screen"><button class="btn btn-primary btn-sm" type="button"><i aria-hidden="true" class="fa fa-pencil-square-o"></i></button></a>
                               <?php endif; ?>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'screens.assignrole_create')): ?>
							   <a href="<?php echo e(route('screens.assignrole_create', $screen->id)); ?>" title="Assign Role"><button class="btn btn-success btn-sm" type="button"><i aria-hidden="true" class="fa fa-key"></i></button></a>
                               <?php endif; ?>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'screens.destroy')): ?>
                               <a href="#" onclick="return individualDelete(<?php echo e($screen->id); ?>)" title="Delete Screen"><button class="btn btn-danger btn-sm" type="button"><i aria-hidden="true" class="fa fa-trash"></i></button></a>
                               <?php endif; ?>
                           </td>
                        </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td class="text-center" colspan="12">No Screen found!</td>
						</tr>
						<?php endif; ?>

                     </tbody>
                  </table>
                  <div class="pagination">
					<?php echo e($screens->links()); ?>

				  </div>
               </div>
			   </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'screen-index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/screens/index.blade.php ENDPATH**/ ?>