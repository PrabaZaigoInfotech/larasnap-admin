<?php $__env->startSection('title','Permission Management'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Permissions</h1>
</div>
<!-- Page Heading End-->				  
<!-- Page Content Start-->				  
<div class="row">
   <div class="col-xl-12">
      <div class="card shadow mb-4">
         <div class="card-body">
            <div class="card-body">
				<form  method="POST" action="<?php echo e(route('permissions.index')); ?>" id="list-form" class="form-inline my-2 my-lg-0" autocomplete="off">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
			   <div class="col-md-2 pad-0">
                   <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'permissions.create')): ?>
               <a href="<?php echo e(route('permissions.create')); ?>" title="Add New Permission" class="btn btn-primary btn-sm"><i aria-hidden="true" class="fa fa-plus"></i> Add New Permission
               </a>
                   <?php endif; ?>
			   </div>
				<!-- list filters -->
				<div class="col-md-10 filters">
					<?php echo $__env->make('larasnap::list-filters.permission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>	
				<!-- list filters -->
               <br> <br> 
               <div class="table-responsive">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>ID</th>
                           <th>Name(Slug)</th>
                           <th>Label</th>
                           <th>Actions</th>
                        </tr>
                     </thead>
                     <tbody>
					<?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
                        <tr>
                           <td><?php echo e($permission->id); ?></td>
                           <td><?php echo e($permission->name); ?></td>
                           <td><?php echo e($permission->label); ?></td>
                           <td>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'permissions.edit')): ?>
							  <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" title="Edit Permission"><button class="btn btn-primary btn-sm" type="button"><i aria-hidden="true" class="fa fa-pencil-square-o"></i></button></a>
                               <?php endif; ?>
                               <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'permissions.destroy')): ?>
                              <a href="#" onclick="return individualDelete(<?php echo e($permission->id); ?>)" title="Delete Permission"><button class="btn btn-danger btn-sm" type="button"><i aria-hidden="true" class="fa fa-trash"></i></button></a>
                               <?php endif; ?>
                           </td>
                        </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td class="text-center" colspan="12">No Permission found!</td>
						</tr>
						<?php endif; ?>

                     </tbody>
                  </table>
                  <div class="pagination">
						<?php echo e($permissions->links()); ?>

				  </div>
               </div>
			   </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('larasnap::layouts.app', ['class' => 'permission-index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/permissions/index.blade.php ENDPATH**/ ?>