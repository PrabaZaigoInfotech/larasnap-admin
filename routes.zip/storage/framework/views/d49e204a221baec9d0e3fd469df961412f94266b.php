<?php if(config('larasnap.module_list.module.search')): ?>				 
   <input type="text" name="search" placeholder="Search Module..." class="form-control ml-10" value="<?php echo e($filters['search']); ?>" data-toggle="tooltip" data-placement="top" title="Search by module label">
<?php endif; ?>				  
<?php /**PATH C:\xampp\htdocs\laravel\admin\resources\views/vendor/larasnap/list-filters/module.blade.php ENDPATH**/ ?>